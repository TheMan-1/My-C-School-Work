#include <iostream>
using namespace std;

int main()
{
    double one, two, total;
    one = 50;
    two = 100;
    total = one + two;

    cout << total;
    return 0;
}