// This program uses integer literals, string literals, and a variable.
#include <iostream>
using namespace std;

int main()
{
    int apples;

    apples = 20;
    cout << "On Sunday we sold " << apples << " bushels of apples. \n";

    apples = 15;
    cout << "On Monday we sold " << apples << " bushles of apples. \n";
    return 0;
}