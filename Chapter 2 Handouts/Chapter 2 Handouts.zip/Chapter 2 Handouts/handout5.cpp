// This program prints a simple smiley face.
#include <iostream>
using namespace std;

int main()
{
    cout << "\n\n";
    cout << "       ^   ^\n";
    cout << "         *\n";
    cout << "       \\__/   \n\n";

    cout << "       o   o\n";
    cout << "         o\n";
    cout << "       (___)\n\n";

    cout << "       ^   ^\n";
    cout << "       v   v\n";
    cout << "         :\n";
    cout << "       \\UUU/";
    return 0;
}